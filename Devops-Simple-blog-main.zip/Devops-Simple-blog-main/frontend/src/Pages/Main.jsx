import React from 'react'

function Main() {
  return (
    <div className='w-full h-auto text-3xl flex justify-center items-center'>
      This is main page of blog website.
    </div>
  )
}

export default Main
