import React from 'react'

export default function Posts() {
  return (
    <div className='w-full h-auto font-2xl font-bold'>
      THis is post page.
    </div>
  )
}
